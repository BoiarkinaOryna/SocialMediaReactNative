import * as yup from "yup";

export const myDataValidator = yup.object({
    name: yup
        .string()
        .required()
        // .nullable(),
        .default(undefined),
    surname: yup
        .string()
        .required()
        .default(undefined),
        // .nullable(),
    birthDate: yup
        .date()
        .required()
        // .nullable(),
        .default(undefined),
    email: yup
        .string()
        .email("Email must contain '@' and '.'")
        .required()
        // .nonNullable()
        .default(undefined)
})

export const albumValidator = yup.object({
    name: yup
        .string()
        .required(),
    theme: yup
        .string()
        .required(),
    year: yup
        .number()
        .required()
        .max(2030, "Year must be before 2030")
        .positive("Year must be a positive number")
        .integer("Year must be an integer")
})